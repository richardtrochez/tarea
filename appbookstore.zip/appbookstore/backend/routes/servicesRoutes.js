import express from 'express'
import {  createService , getServiceById ,getServices, updateService } from '../controller/servicesController.js'

const router= express.Router()


router.post('/', createService)
router.get('/', getServices)
router.get('/:id', getServiceById)
 
export default router

