export const services = [
    { 
        name: 'el viejo y el mar',
        price: 20
    },
    { 
        name: 'the 5 am club',
        price: 35
    },
     { 
         name: ' habitos atomicos',
            price: 85
        },
        { 
            name: 'UIX desing',
            price: 120
        },
        {
            name: 'Big data science',
            price: 155

        }
        
    ];