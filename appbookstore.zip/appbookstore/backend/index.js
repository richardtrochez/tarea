//importaciones
import express from 'express'
import dotenv from 'dotenv'
import colors from 'colors'
import {db} from './config/db.js'
import servicesRoutes from './routes/servicesRoutes.js'


//configuracion de la app
dotenv.config()


//configuracion de la app
const app=express()


//Leer datos via body
app.use(express.json())



//conectar a la base de datos
db()

//definicion de la ruta

app.use('/api/services',servicesRoutes)


//definicion del puerto
const PORT=process.env.PORT ||4009


//ejecucion de la app
 app.listen(PORT, () =>{
    console.log(colors.blue('El servidor se esta ejecutando en el puerto',PORT))

 })